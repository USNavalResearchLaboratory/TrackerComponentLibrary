library(scs)

scs(matrix(c(0.5,2),2,1), c(3, 1), 1, list(l=2), list(max_iters=5000))
