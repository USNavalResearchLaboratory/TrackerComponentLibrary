VectorXf v;
v.setZero(3);
cout << v << endl;
