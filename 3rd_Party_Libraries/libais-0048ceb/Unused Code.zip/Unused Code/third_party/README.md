Third party sources that must be included in the project.

- gtest - revision 708 from https://code.google.com/p/googletest/ on 2015-Mar-15
- gmock - revision 514 from https://code.google.com/p/googlemock/ on 2015-Mar-15

