This directory contains utilities and scripts that are usefull when
developing libais, but that are not generic enough to be put in the
bin directory to be installed by the pypi package.
